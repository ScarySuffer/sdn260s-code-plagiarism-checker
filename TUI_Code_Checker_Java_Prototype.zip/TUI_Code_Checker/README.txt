TUI - Java Code Plagiarism Checker

Files:
- CodeProcessor.java
- SimilarityChecker.java
- Main.java

How to run:
1. Create a Java project named CodePlagiarismChecker in NetBeans.
2. Create package: codeplagiarismchecker
3. Add the three Java files to that package.
4. Run Main.java.
5. Choose 1 and enter the full paths to two .java files.
6. Choose 3 to compare.
7. Choose 4 to save the report.
8. Choose 5 to exit.

This is a basic educational prototype. It compares token shingles with Jaccard similarity.
The score is not proof of plagiarism and requires human review.
