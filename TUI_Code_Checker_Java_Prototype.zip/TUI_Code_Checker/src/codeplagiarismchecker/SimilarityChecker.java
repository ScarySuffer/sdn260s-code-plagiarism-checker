package codeplagiarismchecker;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SimilarityChecker {

    public double calculateSimilarity(List<String> first, List<String> second) {
        if (first.isEmpty() && second.isEmpty()) {
            return 100.0;
        }
        if (first.isEmpty() || second.isEmpty()) {
            return 0.0;
        }

        Set<String> firstShingles = makeShingles(first, 5);
        Set<String> secondShingles = makeShingles(second, 5);

        Set<String> intersection = new HashSet<>(firstShingles);
        intersection.retainAll(secondShingles);

        Set<String> union = new HashSet<>(firstShingles);
        union.addAll(secondShingles);

        if (union.isEmpty()) {
            return 0.0;
        }
        return (intersection.size() * 100.0) / union.size();
    }

    private Set<String> makeShingles(List<String> tokens, int size) {
        Set<String> shingles = new HashSet<>();

        if (tokens.size() < size) {
            if (!tokens.isEmpty()) {
                shingles.add(String.join(" ", tokens));
            }
            return shingles;
        }

        for (int i = 0; i <= tokens.size() - size; i++) {
            shingles.add(String.join(" ", tokens.subList(i, i + size)));
        }
        return shingles;
    }
}