package codeplagiarismchecker;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CodeProcessor {

    public List<String> getTokens(String code) {
        code = code.replaceAll("(?s)/\\*.*?\\*/", " ");
        code = code.replaceAll("(?m)//.*$", " ");
        code = code.replaceAll("\"(?:\\\\.|[^\"\\\\])*\"", " STRING ");
        code = code.replaceAll("'(?:\\\\.|[^'\\\\])*'", " CHAR ");
        code = code.replaceAll("\\s+", " ").trim();

        List<String> tokens = new ArrayList<>();
        Pattern pattern = Pattern.compile(
            "[A-Za-z_$][A-Za-z0-9_$]*|\\d+(?:\\.\\d+)?|==|!=|<=|>=|\\+\\+|--|&&|\\|\\||[^\\s]"
        );
        Matcher matcher = pattern.matcher(code);

        while (matcher.find()) {
            tokens.add(matcher.group());
        }
        return tokens;
    }
}