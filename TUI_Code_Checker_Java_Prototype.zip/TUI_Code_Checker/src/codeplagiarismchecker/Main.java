package codeplagiarismchecker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final CodeProcessor processor = new CodeProcessor();
    private static final SimilarityChecker checker = new SimilarityChecker();

    private static Path fileA;
    private static Path fileB;
    private static String report = "";

    public static void main(String[] args) {
        System.out.println("==============================================");
        System.out.println("       TUI - CODE PLAGIARISM CHECKER");
        System.out.println("       Java Code Similarity Detection");
        System.out.println("==============================================");

        boolean running = true;

        while (running) {
            showMenu();
            System.out.print("Enter your choice (1-5): ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    loadFiles();
                    break;
                case "2":
                    viewFiles();
                    break;
                case "3":
                    compareFiles();
                    break;
                case "4":
                    saveReport();
                    break;
                case "5":
                    running = false;
                    System.out.println("Thank you for using TUI Code Checker. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1 to 5.");
            }
            System.out.println();
        }
        scanner.close();
    }

    private static void showMenu() {
        System.out.println("\nMAIN MENU");
        System.out.println("1. Load Java Files");
        System.out.println("2. View Loaded Files");
        System.out.println("3. Compare Code");
        System.out.println("4. Generate Report");
        System.out.println("5. Exit System");
    }

    private static void loadFiles() {
        try {
            System.out.print("Enter path for Student A Java file: ");
            Path first = Paths.get(scanner.nextLine().trim()).toAbsolutePath().normalize();

            System.out.print("Enter path for Student B Java file: ");
            Path second = Paths.get(scanner.nextLine().trim()).toAbsolutePath().normalize();

            validateJavaFile(first);
            validateJavaFile(second);

            if (first.equals(second)) {
                System.out.println("Please select two different files.");
                return;
            }

            fileA = first;
            fileB = second;
            report = "";
            System.out.println("Student A file loaded: " + fileA.getFileName());
            System.out.println("Student B file loaded: " + fileB.getFileName());
        } catch (IOException | RuntimeException e) {
            System.out.println("Could not load files: " + e.getMessage());
        }
    }

    private static void validateJavaFile(Path path) throws IOException {
        if (!Files.exists(path) || !Files.isRegularFile(path)) {
            throw new IOException("File does not exist: " + path);
        }
        if (!path.getFileName().toString().toLowerCase().endsWith(".java")) {
            throw new IOException("Only .java files are accepted: " + path);
        }
        if (!Files.isReadable(path)) {
            throw new IOException("File cannot be read: " + path);
        }
    }

    private static void viewFiles() {
        if (!filesLoaded()) {
            return;
        }
        System.out.println("Student A: " + fileA);
        System.out.println("Student B: " + fileB);
    }

    private static boolean filesLoaded() {
        if (fileA == null || fileB == null) {
            System.out.println("Please load two Java files first.");
            return false;
        }
        return true;
    }

    private static void compareFiles() {
        if (!filesLoaded()) {
            return;
        }

        try {
            String codeA = new String(Files.readAllBytes(fileA), StandardCharsets.UTF_8);
            String codeB = new String(Files.readAllBytes(fileB), StandardCharsets.UTF_8);

            List<String> tokensA = processor.getTokens(codeA);
            List<String> tokensB = processor.getTokens(codeB);

            double similarity = checker.calculateSimilarity(tokensA, tokensB);

            String status;
            if (similarity >= 70) {
                status = "Requires further review";
            } else if (similarity >= 40) {
                status = "Some similarities found";
            } else {
                status = "Low similarity detected";
            }

            report = buildReport(similarity, status, tokensA.size(), tokensB.size());

            System.out.println("\n============== COMPARISON RESULT ==============");
            System.out.printf("Student A: %s%n", fileA.getFileName());
            System.out.printf("Student B: %s%n", fileB.getFileName());
            System.out.printf("Similarity Score: %.2f%%%n", similarity);
            System.out.println("Status: " + status);
            System.out.println("-----------------------------------------------");
            System.out.println("Tokens in Student A: " + tokensA.size());
            System.out.println("Tokens in Student B: " + tokensB.size());
            System.out.println("Note: Similarity alone does not prove plagiarism.");
            System.out.println("================================================");
        } catch (IOException e) {
            System.out.println("Error reading the selected files: " + e.getMessage());
        }
    }

    private static String buildReport(double similarity, String status, int countA, int countB) {
        return "TUI - CODE PLAGIARISM CHECKER REPORT\n"
            + "====================================\n"
            + "Student A file: " + fileA.getFileName() + "\n"
            + "Student B file: " + fileB.getFileName() + "\n"
            + String.format("Similarity Score: %.2f%%%n", similarity)
            + "Status: " + status + "\n"
            + "Tokens in Student A: " + countA + "\n"
            + "Tokens in Student B: " + countB + "\n"
            + "\nNote: Similarity alone does not prove plagiarism. "
            + "The result requires human review.\n";
    }

    private static void saveReport() {
        if (report.isEmpty()) {
            System.out.println("Please compare two files before saving a report.");
            return;
        }

        System.out.print("Enter report filename (e.g. comparison_report.txt): ");
        String name = scanner.nextLine().trim();

        if (name.isEmpty()) {
            System.out.println("Filename cannot be empty.");
            return;
        }

        Path output = Paths.get(name).toAbsolutePath().normalize();

        try {
            Files.write(output, report.getBytes(StandardCharsets.UTF_8));
            System.out.println("Report saved successfully: " + output);
        } catch (IOException e) {
            System.out.println("Could not save report: " + e.getMessage());
        }
    }
}