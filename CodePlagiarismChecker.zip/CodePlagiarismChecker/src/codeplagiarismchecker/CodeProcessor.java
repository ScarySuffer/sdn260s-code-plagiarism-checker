package codeplagiarismchecker;

import java.util.ArrayList;
import java.util.List;

public class CodeProcessor {
     public List<String> tokenize(String code) {
        List<String> tokens = new ArrayList<>();
        int i = 0;

        while (i < code.length()) {
            char c = code.charAt(i);

            if (Character.isWhitespace(c)) {
                i++;
            } else if (c == '/' && i + 1 < code.length()
                    && code.charAt(i + 1) == '/') {
                i += 2;

                while (i < code.length() && code.charAt(i) != '\n') {
                    i++;
                }
            } else if (c == '/' && i + 1 < code.length()
                    && code.charAt(i + 1) == '*') {
                i += 2;

                while (i + 1 < code.length()
                        && !(code.charAt(i) == '*'
                        && code.charAt(i + 1) == '/')) {
                    i++;
                }

                if (i + 1 < code.length()) {
                    i += 2;
                } else {
                    i = code.length();
                }
            } else if (c == '"' || c == '\'') {
                char quote = c;
                StringBuilder literal = new StringBuilder();
                literal.append(c);
                i++;

                while (i < code.length()) {
                    char next = code.charAt(i);
                    literal.append(next);
                    i++;

                    if (next == '\\' && i < code.length()) {
                        literal.append(code.charAt(i));
                        i++;
                    } else if (next == quote) {
                        break;
                    }
                }

                tokens.add(literal.toString());
            } else if (Character.isJavaIdentifierStart(c)) {
                int start = i;
                i++;

                while (i < code.length()
                        && Character.isJavaIdentifierPart(code.charAt(i))) {
                    i++;
                }

                tokens.add(code.substring(start, i));
            } else if (Character.isDigit(c)) {
                int start = i;
                i++;

                while (i < code.length()
                        && (Character.isLetterOrDigit(code.charAt(i))
                        || code.charAt(i) == '_'
                        || code.charAt(i) == '.')) {
                    i++;
                }

                tokens.add(code.substring(start, i));
            } else {
                String operator = String.valueOf(c);

                if (i + 2 < code.length()) {
                    String three = code.substring(i, i + 3);

                    if (three.equals(">>>") || three.equals("<<=")
                            || three.equals(">>=")) {
                        operator = three;
                    }
                }

                if (operator.length() == 1 && i + 1 < code.length()) {
                    String two = code.substring(i, i + 2);

                    if (two.equals("==") || two.equals("!=")
                            || two.equals("<=") || two.equals(">=")
                            || two.equals("++") || two.equals("--")
                            || two.equals("&&") || two.equals("||")
                            || two.equals("+=") || two.equals("-=")
                            || two.equals("*=") || two.equals("/=")
                            || two.equals("%=") || two.equals("->")
                            || two.equals("::") || two.equals("<<")
                            || two.equals(">>") || two.equals("&=")
                            || two.equals("|=") || two.equals("^=")) {
                        operator = two;
                    }
                }

                tokens.add(operator);
                i += operator.length();
            }
        }

        return tokens;
    }
}
