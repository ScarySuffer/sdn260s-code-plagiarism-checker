package codeplagiarismchecker;

import java.util.ArrayList;
import java.util.List;

public class CodeFile {
    private final String fileName;
    private final String filePath;
    private final String sourceCode;
    private final List<String> tokens;

    public CodeFile(String fileName, String filePath,
                    String sourceCode, List<String> tokens) {
        this.fileName = fileName;
        this.filePath = filePath;
        this.sourceCode = sourceCode;
        this.tokens = List.copyOf(tokens);
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getSourceCode() {
        return sourceCode;
    }

    public List<String> getTokens() {
        return tokens;
    }
}

