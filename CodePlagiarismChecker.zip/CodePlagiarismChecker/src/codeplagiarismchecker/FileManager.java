package codeplagiarismchecker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class FileManager {
    private final CodeProcessor processor = new CodeProcessor();

    public CodeFile loadFile(String filePath) throws IOException {
        Path path = Paths.get(filePath).toAbsolutePath().normalize();

        if (!Files.exists(path) || !Files.isRegularFile(path)) {
            throw new IOException("The selected file does not exist.");
        }

        if (!path.getFileName().toString()
                .toLowerCase().endsWith(".java")) {
            throw new IOException("Only Java files are accepted.");
        }

        if (!Files.isReadable(path)) {
            throw new IOException("The file cannot be read.");
        }

        String sourceCode = Files.readString(
                path, StandardCharsets.UTF_8);

        if (sourceCode.trim().isEmpty()) {
            throw new IOException("The selected file is empty.");
        }

        List<String> tokens = processor.tokenize(sourceCode);

        if (tokens.isEmpty()) {
            throw new IOException("No code tokens were found.");
        }

        return new CodeFile(
                path.getFileName().toString(),
                path.toString(),
                sourceCode,
                tokens);
    }
}
