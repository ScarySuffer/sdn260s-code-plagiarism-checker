package codeplagiarismchecker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class CoreTest {
    public static void main(String[] args) throws IOException {
        CodeProcessor processor = new CodeProcessor();

        String sampleCode =
                "int total = 10; // calculate total\n"
                + "total = total + 5;";

        List<String> tokens = processor.tokenize(sampleCode);

        System.out.println("Test 1: Tokenization");
        System.out.println(tokens);

        if (tokens.contains("calculate")) {
            throw new AssertionError("Comment was not ignored.");
        }

        System.out.println("Passed: Comment text was ignored.");

        Path testFile = Files.createTempFile("StudentTest", ".java");

        try {
            Files.writeString(
                    testFile,
                    "public class StudentTest { int mark = 80; }",
                    StandardCharsets.UTF_8);

            FileManager manager = new FileManager();
            CodeFile file = manager.loadFile(testFile.toString());

            System.out.println("\nTest 2: File loading");
            System.out.println("Filename: " + file.getFileName());
            System.out.println("Token count: " + file.getTokens().size());

            if (file.getTokens().isEmpty()) {
                throw new AssertionError("Tokens were not created.");
            }

            System.out.println("Passed: Java file loaded successfully.");
        } finally {
            Files.deleteIfExists(testFile);
        }

        System.out.println("\nAll core tests passed.");
    }
}
