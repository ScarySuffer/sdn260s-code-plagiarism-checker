
package codeplagiarismchecker;

public class CodePlagiarismChecker {

    public static void main(String[] args) {
        int total = 10; // calculate total
    }
    
}
